﻿using Catedra1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Catedra1.Controllers
{
    public class LoginController : Controller
    {
        private readonly CATEDRAContext _context;

        public LoginController(CATEDRAContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(string nombreUsuario, string clave)
        {
            var usuario = await _context.Usuarios
                .Include(u => u.IdRolNavigation)
                .FirstOrDefaultAsync(u => u.NombreUsuario == nombreUsuario && u.Clave == clave);

            if (usuario != null)
            {
                HttpContext.Session.SetInt32("idUsuario", usuario.IdUsuario);
                HttpContext.Session.SetString("nombreUsuario", usuario.NombreUsuario ?? "");
                HttpContext.Session.SetString("rolUsuario", usuario.IdRolNavigation?.NombreRol ?? "");

                if (usuario.IdRolNavigation?.NombreRol == "Administrador")
                    return RedirectToAction("Index", "Home");
                else
                    return RedirectToAction("Index", "Equipos");
            }

            ViewBag.Mensaje = "❌ Usuario o contraseña incorrecta.";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Registrar()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Registrar(string nombreUsuario, string clave)
        {
            var existe = await _context.Usuarios.AnyAsync(u => u.NombreUsuario == nombreUsuario);
            if (existe)
            {
                ViewBag.Mensaje = "⚠️ El usuario ya está registrado.";
                return View();
            }

            var nuevoUsuario = new Usuario
            {
                NombreUsuario = nombreUsuario,
                Clave = clave,
                IdRol = 1 // Asigna rol de Administrador
            };

            _context.Usuarios.Add(nuevoUsuario);
            await _context.SaveChangesAsync();

            ViewBag.Mensaje = "✅ ¡Usuario registrado exitosamente!";
            return View();
        }
    }
}
