﻿using Catedra1.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Catedra1.Controllers
{
    public class HistorialDevolucionesController : Controller
    {
        private readonly CATEDRAContext _context;

        public HistorialDevolucionesController(CATEDRAContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var historial = await _context.HistorialDevoluciones
                .Include(h => h.IdPrestamoNavigation)
                .ToListAsync();

            return View(historial);
        }

    }

}
