﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Catedra1.Models;

namespace Catedra1.Controllers
{
    public class PrestamosController : Controller
    {
        private readonly CATEDRAContext _context;

        public PrestamosController(CATEDRAContext context)
        {
            _context = context;
        }

        // GET: Prestamos
        public async Task<IActionResult> Index()
        {
            var usuarioRol = HttpContext.Session.GetString("rolUsuario");
            var usuarioId = HttpContext.Session.GetInt32("idUsuario");

            IQueryable<Prestamo> prestamos = _context.Prestamos
                .Include(p => p.IdEstudianteNavigation)
                .Include(p => p.IdEquipoNavigation);

            if (usuarioRol == "Estudiante" && usuarioId.HasValue)
            {
                prestamos = prestamos.Where(p => p.IdEstudiante == usuarioId.Value);
            }

            return View(await prestamos.ToListAsync());
        }

        // GET: Prestamos/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var prestamo = await _context.Prestamos
                .Include(p => p.IdEstudianteNavigation)
                .Include(p => p.IdEquipoNavigation)
                .FirstOrDefaultAsync(p => p.IdPrestamo == id);

            if (prestamo == null) return NotFound();

            return View(prestamo);
        }

        // GET: Prestamos/Create
        public IActionResult Create()
        {
            ViewData["IdEstudiante"] = new SelectList(_context.Estudiantes, "IdEstudiante", "Nombre");
            ViewData["IdEquipo"] = new SelectList(_context.Equipos
                .Where(e => e.EstadoEquipo == "Disponible" && e.CantidadDisponible > 0), "IdEquipo", "NombreEquipo");
            return View();
        }

        // POST: Prestamos/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdPrestamo,IdEstudiante,IdEquipo,FechaPrestamo,FechaDevolucion")] Prestamo prestamo)
        {
            var equipo = await _context.Equipos.FindAsync(prestamo.IdEquipo);

            if (equipo == null || equipo.CantidadDisponible <= 0)
            {
                ModelState.AddModelError("", "No hay unidades disponibles de este equipo.");
            }

            if (ModelState.IsValid)
            {
                equipo.CantidadDisponible -= 1;

                if (equipo.CantidadDisponible == 0)
                {
                    equipo.EstadoEquipo = "Prestado";
                }

                _context.Add(prestamo);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewData["IdEstudiante"] = new SelectList(_context.Estudiantes, "IdEstudiante", "Nombre", prestamo.IdEstudiante);
            ViewData["IdEquipo"] = new SelectList(_context.Equipos
                .Where(e => e.EstadoEquipo == "Disponible" && e.CantidadDisponible > 0), "IdEquipo", "NombreEquipo", prestamo.IdEquipo);
            return View(prestamo);
        }

        // GET: Prestamos/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var prestamo = await _context.Prestamos.FindAsync(id);
            if (prestamo == null) return NotFound();

            ViewData["IdEstudiante"] = new SelectList(_context.Estudiantes, "IdEstudiante", "Nombre", prestamo.IdEstudiante);
            ViewData["IdEquipo"] = new SelectList(_context.Equipos, "IdEquipo", "NombreEquipo", prestamo.IdEquipo);
            return View(prestamo);
        }

        // POST: Prestamos/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdPrestamo,IdEstudiante,IdEquipo,FechaPrestamo,FechaDevolucion,FechaDevolucionEstimada,FechaDevolucionReal,EstadoPrestamo")] Prestamo prestamo)
        {
            if (id != prestamo.IdPrestamo) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(prestamo);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Prestamos.Any(e => e.IdPrestamo == prestamo.IdPrestamo))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            ViewData["IdEstudiante"] = new SelectList(_context.Estudiantes, "IdEstudiante", "Nombre", prestamo.IdEstudiante);
            ViewData["IdEquipo"] = new SelectList(_context.Equipos, "IdEquipo", "NombreEquipo", prestamo.IdEquipo);
            return View(prestamo);
        }

        // GET: Prestamos/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var prestamo = await _context.Prestamos
                .Include(p => p.IdEstudianteNavigation)
                .Include(p => p.IdEquipoNavigation)
                .FirstOrDefaultAsync(m => m.IdPrestamo == id);

            if (prestamo == null) return NotFound();

            return View(prestamo);
        }

        // POST: Prestamos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var prestamo = await _context.Prestamos.FindAsync(id);
            if (prestamo != null)
            {
                var equipo = await _context.Equipos.FindAsync(prestamo.IdEquipo);

                if (equipo != null)
                {
                    equipo.CantidadDisponible += 1;

                    if (equipo.CantidadDisponible > 0)
                    {
                        equipo.EstadoEquipo = "Disponible";
                    }
                }

                _context.Prestamos.Remove(prestamo);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        // POST: Prestamos/MarcarComoDevuelto/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarcarComoDevuelto(int id)
        {
            var prestamo = await _context.Prestamos
                .Include(p => p.IdEquipoNavigation)
                .FirstOrDefaultAsync(p => p.IdPrestamo == id);

            if (prestamo == null) return NotFound();

            if (prestamo.EstadoPrestamo == "Devuelto")
            {
                TempData["Mensaje"] = "Este préstamo ya está marcado como devuelto.";
                return RedirectToAction(nameof(Index));
            }

            prestamo.EstadoPrestamo = "Devuelto";
            prestamo.FechaDevolucionReal = DateTime.Now;

            var equipo = prestamo.IdEquipoNavigation;
            equipo.CantidadDisponible += 1;

            if (equipo.CantidadDisponible > 0)
            {
                equipo.EstadoEquipo = "Disponible";
            }

            _context.Update(prestamo);
            await _context.SaveChangesAsync();

            TempData["Mensaje"] = "Préstamo marcado como devuelto exitosamente.";
            return RedirectToAction(nameof(Index));
        }
    }
}
