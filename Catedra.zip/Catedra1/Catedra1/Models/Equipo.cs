﻿using System;
using System.Collections.Generic;

namespace Catedra1.Models
{
    public partial class Equipo
    {
        public Equipo()
        {
            ColasDeEsperas = new HashSet<ColasDeEspera>();
            Prestamos = new HashSet<Prestamo>();
        }

        public int IdEquipo { get; set; }
        public string? CodigoEquipo { get; set; }
        public string? NombreEquipo { get; set; }
        public string? TipoEquipo { get; set; }
        public string? EstadoEquipo { get; set; }
        public string? Ubicacion { get; set; }
        public int? CantidadDisponible { get; set; }


        public virtual ICollection<ColasDeEspera> ColasDeEsperas { get; set; }
        public virtual ICollection<Prestamo> Prestamos { get; set; }
    }
}
