﻿using System;
using System.Collections.Generic;

namespace Catedra1.Models
{
    public partial class ColasDeEspera
    {
        public int IdCola { get; set; }
        public int? IdEquipo { get; set; }
        public int? IdEstudiante { get; set; }
        public DateTime? FechaIngresoCola { get; set; }

        public virtual Equipo? IdEquipoNavigation { get; set; }
        public virtual Estudiante? IdEstudianteNavigation { get; set; }
    }
}
