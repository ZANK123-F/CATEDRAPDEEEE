﻿using System;
using System.Collections.Generic;

namespace Catedra1.Models
{
    public partial class Estudiante
    {
        public Estudiante()
        {
            ColasDeEsperas = new HashSet<ColasDeEspera>();
            Prestamos = new HashSet<Prestamo>();
        }

        public int IdEstudiante { get; set; }
        public string? Nombre { get; set; }
        public string? CarnetEstudiante { get; set; }
        public string? Carrera { get; set; }
        public string? Grupo { get; set; }
        public int? IdCarrera { get; set; }

      
        public Carrera? CarreraNavigation { get; set; }

        public virtual ICollection<ColasDeEspera> ColasDeEsperas { get; set; }
        public virtual ICollection<Prestamo> Prestamos { get; set; }
    }
}
