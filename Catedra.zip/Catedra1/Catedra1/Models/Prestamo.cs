﻿using System;
using System.Collections.Generic;

namespace Catedra1.Models
{
    public partial class Prestamo
    {
        public Prestamo()
        {
            HistorialDevoluciones = new HashSet<HistorialDevolucione>();
        }

        public int IdPrestamo { get; set; }
        public int? IdEstudiante { get; set; }
        public int? IdEquipo { get; set; }
        public DateTime? FechaPrestamo { get; set; }
        public DateTime? FechaDevolucionEstimada { get; set; }
        public DateTime? FechaDevolucionReal { get; set; }
        public string? EstadoPrestamo { get; set; }

        public virtual Equipo? IdEquipoNavigation { get; set; }
        public virtual Estudiante? IdEstudianteNavigation { get; set; }
        public virtual ICollection<HistorialDevolucione> HistorialDevoluciones { get; set; }
    }
}
