﻿using System;
using System.Collections.Generic;

namespace Catedra1.Models
{
    public partial class HistorialDevolucione
    {
        public int IdDevolucion { get; set; }
        public int? IdPrestamo { get; set; }
        public DateTime? FechaDevolucion { get; set; }
        public string? EstadoEquipoDespuesDeDevolucion { get; set; }

        public virtual Prestamo? IdPrestamoNavigation { get; set; }
    }
}
