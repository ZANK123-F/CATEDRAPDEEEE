﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Catedra1.Models
{
    public class Carrera
    {
        [Key]
        public int IdCarrera { get; set; }

        [Required]
        [Display(Name = "Nombre de la Carrera")]
        public string NombreCarrera { get; set; }

        public ICollection<Estudiante>? Estudiantes { get; set; }
    }
}
