﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Catedra1.Models
{
    public partial class CATEDRAContext : DbContext
    {
        public CATEDRAContext()
        {
        }

        public CATEDRAContext(DbContextOptions<CATEDRAContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ColasDeEspera> ColasDeEsperas { get; set; } = null!;
        public virtual DbSet<Equipo> Equipos { get; set; } = null!;
        public virtual DbSet<Estudiante> Estudiantes { get; set; } = null!;
        public virtual DbSet<HistorialDevolucione> HistorialDevoluciones { get; set; } = null!;
        public virtual DbSet<Prestamo> Prestamos { get; set; } = null!;
        public virtual DbSet<Role> Roles { get; set; } = null!;
        public virtual DbSet<Usuario> Usuarios { get; set; } = null!;
        public virtual DbSet<Carrera> Carreras { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // optionsBuilder.UseSqlServer("server=localhost; database=CATEDRA; integrated security=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ColasDeEspera>(entity =>
            {
                entity.HasKey(e => e.IdCola);
                entity.ToTable("ColasDeEspera");

                entity.Property(e => e.IdCola).HasColumnName("idCola");
                entity.Property(e => e.FechaIngresoCola).HasColumnType("datetime");
                entity.Property(e => e.IdEquipo).HasColumnName("idEquipo");
                entity.Property(e => e.IdEstudiante).HasColumnName("idEstudiante");

                entity.HasOne(d => d.IdEquipoNavigation)
                      .WithMany(p => p.ColasDeEsperas)
                      .HasForeignKey(d => d.IdEquipo);

                entity.HasOne(d => d.IdEstudianteNavigation)
                      .WithMany(p => p.ColasDeEsperas)
                      .HasForeignKey(d => d.IdEstudiante);
            });

            modelBuilder.Entity<Equipo>(entity =>
            {
                entity.HasKey(e => e.IdEquipo);
                entity.Property(e => e.IdEquipo).HasColumnName("idEquipo");
                entity.Property(e => e.CodigoEquipo).HasMaxLength(50).IsUnicode(false);
                entity.Property(e => e.NombreEquipo).HasMaxLength(100).IsUnicode(false);
                entity.Property(e => e.TipoEquipo).HasMaxLength(50).IsUnicode(false);
                entity.Property(e => e.EstadoEquipo).HasMaxLength(20).IsUnicode(false);
                entity.Property(e => e.Ubicacion).HasMaxLength(100).IsUnicode(false);
                entity.Property(e => e.CantidadDisponible).HasColumnName("cantidadDisponible");
            });

            modelBuilder.Entity<Estudiante>(entity =>
            {
                entity.HasKey(e => e.IdEstudiante);
                entity.Property(e => e.IdEstudiante).HasColumnName("idEstudiante");
                entity.Property(e => e.Nombre).HasMaxLength(100).IsUnicode(false);
                entity.Property(e => e.CarnetEstudiante).HasMaxLength(50).IsUnicode(false);
                entity.Property(e => e.Grupo).HasMaxLength(50).IsUnicode(false);
                entity.Property(e => e.IdCarrera).HasColumnName("idCarrera");

                entity.HasOne(d => d.CarreraNavigation)
                      .WithMany(p => p.Estudiantes)
                      .HasForeignKey(d => d.IdCarrera)
                      .HasConstraintName("FK_Estudiantes_Carreras");
            });

            modelBuilder.Entity<HistorialDevolucione>(entity =>
            {
                entity.HasKey(e => e.IdDevolucion);
                entity.Property(e => e.IdDevolucion).HasColumnName("idDevolucion");
                entity.Property(e => e.FechaDevolucion).HasColumnType("datetime");
                entity.Property(e => e.EstadoEquipoDespuesDeDevolucion).HasMaxLength(20).IsUnicode(false);
                entity.Property(e => e.IdPrestamo).HasColumnName("idPrestamo");

                entity.HasOne(d => d.IdPrestamoNavigation)
                      .WithMany(p => p.HistorialDevoluciones)
                      .HasForeignKey(d => d.IdPrestamo);
            });

            modelBuilder.Entity<Prestamo>(entity =>
            {
                entity.HasKey(e => e.IdPrestamo);
                entity.Property(e => e.IdPrestamo).HasColumnName("idPrestamo");
                entity.Property(e => e.FechaPrestamo).HasColumnType("datetime");
                entity.Property(e => e.FechaDevolucionEstimada).HasColumnType("datetime");
                entity.Property(e => e.FechaDevolucionReal).HasColumnType("datetime");
                entity.Property(e => e.EstadoPrestamo).HasMaxLength(20).IsUnicode(false);
                entity.Property(e => e.IdEstudiante).HasColumnName("idEstudiante");
                entity.Property(e => e.IdEquipo).HasColumnName("idEquipo");

                entity.HasOne(d => d.IdEstudianteNavigation)
                      .WithMany(p => p.Prestamos)
                      .HasForeignKey(d => d.IdEstudiante);

                entity.HasOne(d => d.IdEquipoNavigation)
                      .WithMany(p => p.Prestamos)
                      .HasForeignKey(d => d.IdEquipo);
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasKey(e => e.IdRol);
                entity.Property(e => e.IdRol).HasColumnName("idRol");
                entity.Property(e => e.NombreRol).HasMaxLength(50).IsUnicode(false);
            });

            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.HasKey(e => e.IdUsuario);
                entity.Property(e => e.IdUsuario).HasColumnName("idUsuario");
                entity.Property(e => e.NombreUsuario).HasMaxLength(100).IsUnicode(false);
                entity.Property(e => e.Clave).HasMaxLength(255).IsUnicode(false);
                entity.Property(e => e.IdRol).HasColumnName("idRol");

                entity.HasOne(d => d.IdRolNavigation)
                      .WithMany(p => p.Usuarios)
                      .HasForeignKey(d => d.IdRol);
            });

            modelBuilder.Entity<Carrera>(entity =>
            {
                entity.HasKey(e => e.IdCarrera);
                entity.Property(e => e.IdCarrera).HasColumnName("idCarrera");
                entity.Property(e => e.NombreCarrera).HasMaxLength(100).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}